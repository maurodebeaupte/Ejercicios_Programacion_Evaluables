// ex05_01_expresiones.cpp
// Ejercicio 5.1 - Valor de x después de cada instrucción.
//
// RESPUESTAS:
// a) x = fabs(7.5);                      -> 7.5
// b) x = floor(7.5);                     -> 7.0
// c) x = fabs(0.0);                      -> 0.0
// d) x = ceil(0.0);                      -> 0.0
// e) x = fabs(-6.4);                     -> 6.4
// f) x = ceil(-6.4);                     -> -6.0
// g) x = ceil(-fabs(-8 + floor(-5.5)));  -> -14.0
//    floor(-5.5) = -6  ->  -8 + (-6) = -14  ->  fabs = 14  ->  -14  ->  ceil = -14
//
// fabs = valor absoluto, floor = redondeo hacia abajo, ceil = redondeo hacia arriba.
// Este programa lo comprueba mostrando cada resultado.

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main() {
   double x;
   cout << fixed << setprecision(1);

   x = fabs(7.5);
   cout << "a) fabs(7.5) = " << x << "\n";

   x = floor(7.5);
   cout << "b) floor(7.5) = " << x << "\n";

   x = fabs(0.0);
   cout << "c) fabs(0.0) = " << x << "\n";

   x = ceil(0.0);
   cout << "d) ceil(0.0) = " << x << "\n";

   x = fabs(-6.4);
   cout << "e) fabs(-6.4) = " << x << "\n";

   x = ceil(-6.4);
   cout << "f) ceil(-6.4) = " << x << "\n";

   x = ceil(-fabs(-8 + floor(-5.5)));
   cout << "g) ceil(-fabs(-8 + floor(-5.5))) = " << x << "\n";
}
