// ex04_08_producto_impares.cpp
// Ejercicio 4.8 - Calcula el producto de los enteros impares del 1 al 15.
// 1 * 3 * 5 * 7 * 9 * 11 * 13 * 15 = 2027025

#include <iostream>
using namespace std;

int main() {
   long long producto{1};

   for (int i{1}; i <= 15; i += 2) {
      producto *= i;
   }

   cout << "Producto de los impares del 1 al 15: " << producto << "\n";
}
