// ex04_06.cpp
// Ejercicio 4.6 - ¿Qué hace el siguiente programa?
//
// RESPUESTA:
// Son dos bucles for anidados. El exterior se repite 10 veces (i = 1..10) y,
// en cada vuelta, el interior imprime 5 arrobas '@' (j = 1..5) seguidas de un
// salto de línea. El resultado es un rectángulo de 10 filas x 5 columnas:
//
// @@@@@
// @@@@@
// @@@@@
// @@@@@
// @@@@@
// @@@@@
// @@@@@
// @@@@@
// @@@@@
// @@@@@

#include <iostream>
using namespace std;

int main() {
   for (int i{1}; i <= 10; i++) {
      for (int j{1}; j <= 5; j++) {
         cout << '@';
      }

      cout << '\n';
   }
}
