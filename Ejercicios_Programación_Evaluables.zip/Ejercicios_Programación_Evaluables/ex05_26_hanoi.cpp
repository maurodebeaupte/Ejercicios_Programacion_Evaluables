// ex05_26_hanoi.cpp
// Ejercicio 5.26 - Torres de Hanói con una función recursiva.
// Para mover n discos de la varilla origen a la de destino:
//  a) se mueven n-1 discos de origen a la varilla temporal (usando destino)
//  b) se mueve el disco más grande de origen a destino
//  c) se mueven los n-1 discos de la temporal a destino (usando origen)
// Caso base: con 1 disco se mueve directamente.
// "1 -> 3" significa "mover un disco de la varilla 1 a la varilla 3".

#include <iostream>
using namespace std;

void hanoi(int discos, int origen, int destino, int temporal); // prototipo

int main() {
   int discos{0};

   while (discos < 1) {
      cout << "¿Cuántos discos quieres mover? ";
      cin >> discos;
   }

   cout << "Movimientos para pasar " << discos
        << " discos de la varilla 1 a la varilla 3:\n";
   hanoi(discos, 1, 3, 2);
}

// discos: número de discos a mover
// origen: varilla donde están los discos
// destino: varilla a la que hay que llevarlos
// temporal: varilla que se usa de apoyo
void hanoi(int discos, int origen, int destino, int temporal) {
   if (discos == 1) { // caso base
      cout << origen << " -> " << destino << "\n";
      return;
   }

   hanoi(discos - 1, origen, temporal, destino);  // a)
   cout << origen << " -> " << destino << "\n";   // b)
   hanoi(discos - 1, temporal, destino, origen);  // c)
}
