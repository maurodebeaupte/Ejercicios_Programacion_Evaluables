// ex04_15_pi.cpp
// Ejercicio 4.15 - Cálculo del valor de pi con la serie:
//    pi = 4 - 4/3 + 4/5 - 4/7 + 4/9 - 4/11 + ...
// Muestra una tabla con la aproximación tras cada uno de los primeros 200000
// términos y, al final, en qué término aparece por primera vez un valor que
// empieza por 3.14159.
//
// Consejo: la tabla tiene 200000 líneas; para verla con calma se puede
// redirigir a un fichero:  ./pi > tabla_pi.txt

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
   const int TERMINOS{200000};
   double pi{0.0};
   double signo{1.0};
   int primerTermino{0}; // término en el que aparece 3.14159 por primera vez

   cout << "Accuracy set at: " << TERMINOS << "\n\n";
   cout << left << setw(8) << "term" << "pi\n";
   cout << fixed << setprecision(8);

   for (int termino{1}; termino <= TERMINOS; ++termino) {
      double denominador{2.0 * termino - 1.0}; // 1, 3, 5, 7, ...
      pi += signo * 4.0 / denominador;
      signo = -signo;

      cout << left << setw(8) << termino << pi << "\n";

      // "empieza por 3.14159" significa 3.14159 <= pi < 3.14160
      if (primerTermino == 0 && pi >= 3.14159 && pi < 3.14160) {
         primerTermino = termino;
      }
   }

   cout << "\nSe obtiene por primera vez un valor que empieza por 3.14159 "
        << "en el término " << primerTermino << "\n";
}
