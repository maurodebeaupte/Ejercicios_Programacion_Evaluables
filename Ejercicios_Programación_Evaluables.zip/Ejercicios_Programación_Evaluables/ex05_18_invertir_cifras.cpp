// ex05_18_invertir_cifras.cpp
// Ejercicio 5.18 - Función que recibe un entero y devuelve el número con sus
// cifras en orden inverso. Ejemplo: 7631 -> 1367

#include <iostream>
using namespace std;

int reverseDigits(int numero); // prototipo

int main() {
   int numero;
   cout << "Introduce un número entero: ";
   cin >> numero;

   cout << "Con las cifras invertidas: " << reverseDigits(numero) << "\n";
}

// Devuelve el número con las cifras al revés (respeta el signo)
int reverseDigits(int numero) {
   int signo{numero < 0 ? -1 : 1};
   numero *= signo; // trabajamos con el valor positivo

   int invertido{0};

   while (numero > 0) {
      invertido = invertido * 10 + numero % 10; // añadimos la última cifra
      numero /= 10;                             // y la quitamos del original
   }

   return invertido * signo;
}
