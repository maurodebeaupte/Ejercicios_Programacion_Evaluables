// ex05_06_aleatorios.cpp
// Ejercicio 5.6 - Instrucciones que asignan a n enteros aleatorios en
// distintos intervalos.
//
// Se usa la librería <random> (C++11 en adelante), como en el libro:
// un motor default_random_engine y uniform_int_distribution{min, max},
// que genera enteros entre min y max, ambos incluidos.
//
// Equivalente "clásico" con rand() (fórmula: min + rand() % (max - min + 1)):
//   a) n = 1 + rand() % 2;
//   b) n = 1 + rand() % 100;
//   c) n = rand() % 10;
//   d) n = 1000 + rand() % 113;
//   e) n = -1 + rand() % 3;
//   f) n = -3 + rand() % 15;

#include <iostream>
#include <random>
#include <ctime>
using namespace std;

int main() {
   default_random_engine engine{static_cast<unsigned int>(time(0))};
   int n;

   // a) 1 <= n <= 2
   uniform_int_distribution<int> a{1, 2};
   n = a(engine);
   cout << "a) 1 <= n <= 2       -> " << n << "\n";

   // b) 1 <= n <= 100
   uniform_int_distribution<int> b{1, 100};
   n = b(engine);
   cout << "b) 1 <= n <= 100     -> " << n << "\n";

   // c) 0 <= n <= 9
   uniform_int_distribution<int> c{0, 9};
   n = c(engine);
   cout << "c) 0 <= n <= 9       -> " << n << "\n";

   // d) 1000 <= n <= 1112
   uniform_int_distribution<int> d{1000, 1112};
   n = d(engine);
   cout << "d) 1000 <= n <= 1112 -> " << n << "\n";

   // e) -1 <= n <= 1
   uniform_int_distribution<int> e{-1, 1};
   n = e(engine);
   cout << "e) -1 <= n <= 1      -> " << n << "\n";

   // f) -3 <= n <= 11
   uniform_int_distribution<int> f{-3, 11};
   n = f(engine);
   cout << "f) -3 <= n <= 11     -> " << n << "\n";
}
