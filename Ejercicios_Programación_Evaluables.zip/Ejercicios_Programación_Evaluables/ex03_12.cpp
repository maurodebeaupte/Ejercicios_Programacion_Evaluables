// ex03_12.cpp
// Ejercicio 3.12 - ¿Qué muestra en pantalla el siguiente programa?
//
// RESPUESTA:
// El bucle exterior recorre row de 10 a 1 (10 filas). En cada fila, el bucle
// interior imprime 10 caracteres: "<" si row es impar y ">" si row es par.
// Empieza en row = 10 (par), así que la primera fila es de ">" y luego alterna:
//
// >>>>>>>>>>
// <<<<<<<<<<
// >>>>>>>>>>
// <<<<<<<<<<
// >>>>>>>>>>
// <<<<<<<<<<
// >>>>>>>>>>
// <<<<<<<<<<
// >>>>>>>>>>
// <<<<<<<<<<

#include <iostream>
using namespace std;

int main() {
   int row{10};

   while (row >= 1) {
      int column{1};

      while (column <= 10) {
         cout << (row % 2 == 1 ? "<" : ">");
         ++column;
      }

      --row;
      cout << "\n";
   }
}
