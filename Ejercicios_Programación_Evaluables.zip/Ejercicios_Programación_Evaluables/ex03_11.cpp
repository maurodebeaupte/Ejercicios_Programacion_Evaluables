// ex03_11.cpp
// Ejercicio 3.11 - ¿Qué muestra en pantalla el siguiente programa?
//
// RESPUESTA:
// El bucle va de count = 1 a count = 10. Si count es impar (count % 2 == 1)
// imprime "****"; si es par imprime "++++++++". Por tanto alterna 10 líneas:
//
// ****
// ++++++++
// ****
// ++++++++
// ****
// ++++++++
// ****
// ++++++++
// ****
// ++++++++

#include <iostream>
using namespace std;

int main() {
   int count{1};

   while (count <= 10) {
      cout << (count % 2 == 1 ? "****" : "++++++++") << "\n";
      ++count;
   }
}
