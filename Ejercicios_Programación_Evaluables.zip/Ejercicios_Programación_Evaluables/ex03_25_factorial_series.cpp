// ex03_25_factorial_series.cpp
// Ejercicio 3.25 - Factorial y aproximaciones mediante series.
// Se usan instrucciones while en los tres apartados.
//
// a) Lee un entero no negativo y muestra su factorial. Se usa cpp_int de
//    Boost Multiprecision porque el factorial crece muy rápido y se sale de
//    los tipos enteros normales (21! ya no cabe en un unsigned long long).
// b) Estima e con la serie  e = 1 + 1/1! + 1/2! + 1/3! + ...
// c) Calcula e^x con la serie  e^x = 1 + x/1! + x^2/2! + x^3/3! + ...
// En b) y c) el usuario indica la precisión (número de términos de la suma).
//
// Compilar: g++ -std=c++17 ex03_25_factorial_series.cpp -o ex03_25
// (necesita la librería Boost instalada, solo cabeceras)

#include <iostream>
#include <iomanip>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std;
using boost::multiprecision::cpp_int;

int main() {
   // ---------------- a) Factorial ----------------
   cout << "=== a) Factorial ===\n";
   int n{-1};

   while (n < 0) { // pedimos el número hasta que sea no negativo
      cout << "Introduce un entero no negativo: ";
      cin >> n;
   }

   cpp_int factorial{1}; // 0! = 1 y 1! = 1
   int contador{n};

   while (contador > 1) {
      factorial *= contador;
      --contador;
   }

   cout << n << "! = " << factorial << "\n\n";

   // ---------------- b) Estimación de e ----------------
   cout << "=== b) Estimación de e ===\n";
   int terminosE{0};

   while (terminosE < 1) {
      cout << "Introduce el número de términos (precisión): ";
      cin >> terminosE;
   }

   double e{1.0};          // primer término: 1
   double fact{1.0};       // vamos calculando i! poco a poco
   int i{1};

   while (i < terminosE) {
      fact *= i;           // i! = (i-1)! * i
      e += 1.0 / fact;
      ++i;
   }

   cout << "Valor estimado de e con " << terminosE << " términos: "
        << fixed << setprecision(15) << e << "\n\n";
   cout << defaultfloat << setprecision(6); // volvemos al formato normal

   // ---------------- c) Cálculo de e^x ----------------
   cout << "=== c) Cálculo de e^x ===\n";
   double x{0.0};
   int terminosX{0};

   cout << "Introduce el valor de x: ";
   cin >> x;

   while (terminosX < 1) {
      cout << "Introduce el número de términos (precisión): ";
      cin >> terminosX;
   }

   double resultado{1.0};  // primer término: 1
   double termino{1.0};    // término actual: x^k / k!
   int k{1};

   while (k < terminosX) {
      termino = termino * x / k;   // x^k/k! = (x^(k-1)/(k-1)!) * x / k
      resultado += termino;
      ++k;
   }

   cout << "e^" << x << " con " << terminosX << " términos = "
        << fixed << setprecision(15) << resultado << "\n";
}
