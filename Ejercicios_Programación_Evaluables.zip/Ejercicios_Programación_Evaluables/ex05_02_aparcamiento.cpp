// ex05_02_aparcamiento.cpp
// Ejercicio 5.2 - Tarifas de aparcamiento.
// - Hasta 3 horas: 20.00 $
// - A partir de 3 horas: 5.00 $ más por cada hora o fracción de hora
// - Máximo por 24 horas: 50.00 $
// Se piden las horas de 3 clientes, se muestra una tabla y el total del día.
//
// Nota: en el enunciado del libro el total del ejemplo aparece como 95.50,
// pero 20.00 + 25.00 + 50.00 = 95.00, que es lo que muestra este programa.

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

double calculateCharges(double horas); // prototipo

int main() {
   const int CLIENTES{3};
   double horas[CLIENTES];

   for (int i{0}; i < CLIENTES; ++i) {
      do {
         cout << "Horas aparcadas por el coche " << i + 1 << " (0-24): ";
         cin >> horas[i];
      } while (horas[i] < 0 || horas[i] > 24);
   }

   double totalHoras{0.0};
   double totalCobrado{0.0};

   cout << "\n" << left << setw(8) << "Car" << right << setw(8) << "Hours"
        << setw(10) << "Charge" << "\n";
   cout << fixed;

   for (int i{0}; i < CLIENTES; ++i) {
      double importe{calculateCharges(horas[i])};
      totalHoras += horas[i];
      totalCobrado += importe;

      cout << left << setw(8) << i + 1 << right << setw(8) << setprecision(1)
           << horas[i] << setw(10) << setprecision(2) << importe << "\n";
   }

   cout << left << setw(8) << "TOTAL" << right << setw(8) << setprecision(1)
        << totalHoras << setw(10) << setprecision(2) << totalCobrado << "\n";
}

// Calcula lo que debe pagar un cliente según las horas aparcadas
double calculateCharges(double horas) {
   const double MINIMO{20.0};
   const double POR_HORA{5.0};
   const double MAXIMO{50.0};

   if (horas <= 3.0) {
      return MINIMO;
   }

   // cada hora o fracción por encima de 3 cuenta como hora completa
   double horasExtra{ceil(horas - 3.0)};
   double importe{MINIMO + horasExtra * POR_HORA};

   if (importe > MAXIMO) {
      importe = MAXIMO;
   }

   return importe;
}
