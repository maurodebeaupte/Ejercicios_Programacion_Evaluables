// ex05_21_moneda.cpp
// Ejercicio 5.21 - Simula 100 lanzamientos de una moneda.
// En cada lanzamiento muestra Heads (cara) o Tails (cruz) y al final cuántas
// veces ha salido cada una. La función flip() no recibe argumentos y devuelve
// 0 para cruz (Tails) y 1 para cara (Heads).

#include <iostream>
#include <random>
#include <ctime>
using namespace std;

int flip(); // prototipo

int main() {
   int caras{0};
   int cruces{0};

   for (int lanzamiento{1}; lanzamiento <= 100; ++lanzamiento) {
      if (flip() == 1) {
         cout << "Heads ";
         ++caras;
      }
      else {
         cout << "Tails ";
         ++cruces;
      }

      if (lanzamiento % 10 == 0) { // 10 resultados por línea
         cout << "\n";
      }
   }

   cout << "\nHeads (cara): " << caras << " veces\n";
   cout << "Tails (cruz): " << cruces << " veces\n";
}

// Devuelve 0 (cruz) o 1 (cara) con la misma probabilidad
int flip() {
   static default_random_engine engine{static_cast<unsigned int>(time(0))};
   static uniform_int_distribution<int> moneda{0, 1};
   return moneda(engine);
}
